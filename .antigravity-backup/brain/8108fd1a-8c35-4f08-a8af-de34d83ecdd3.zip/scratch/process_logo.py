import os
import sys
from PIL import Image, ImageOps, ImageFilter

input_path = r"C:\Users\e\.gemini\antigravity\brain\8108fd1a-8c35-4f08-a8af-de34d83ecdd3\.user_uploaded\media_1789035754486.png"
output_dir = r"C:\Users\e\.gemini\antigravity\scratch\portfolio"

img = Image.open(input_path).convert("RGBA")
print(f"Original size: {img.size}")

# Let's crop tight to the drawing content
# Convert to grayscale to find bounding box of dark pixels
gray = ImageOps.grayscale(img)
# Invert so black lines become bright
inv = ImageOps.invert(gray)
# Threshold to find bounding box
bbox = inv.point(lambda p: 255 if p > 30 else 0).getbbox()
print(f"Bounding box: {bbox}")

# Crop with a slight margin
margin = 20
width, height = img.size
left = max(0, bbox[0] - margin)
top = max(0, bbox[1] - margin)
right = min(width, bbox[2] + margin)
bottom = min(height, bbox[3] + margin)
cropped = img.crop((left, top, right, bottom))
cropped_gray = gray.crop((left, top, right, bottom))

# Create Variant 1: White lines on transparent background
# High darkness in original = high opacity in output.
# Pixels that were pure white (255 in cropped_gray) -> alpha = 0
# Pixels that were pure black (0 in cropped_gray) -> alpha = 255
w_img = Image.new("RGBA", cropped.size, (255, 255, 255, 0))
# Let's compute alpha smoothly
# In original, background is ~250-255, lines are 0-100
pixels_gray = cropped_gray.load()
pixels_w = w_img.load()

cw, ch = cropped.size
for y in range(ch):
    for x in range(cw):
        val = pixels_gray[x, y]
        # Invert: 255 (white) -> 0, 0 (black) -> 255
        # Soft curve for smooth antialiasing
        if val > 240:
            alpha = 0
        elif val < 60:
            alpha = 255
        else:
            # Linear map 240 -> 0 to 60 -> 255
            alpha = int((240 - val) / (240 - 60) * 255)
        
        pixels_w[x, y] = (255, 255, 255, alpha)

# Save white transparent version
w_img.save(os.path.join(output_dir, "logo-white.png"))
print("Saved logo-white.png")

# Also create Variant 2: Original black lines on transparent background
b_img = Image.new("RGBA", cropped.size, (0, 0, 0, 0))
pixels_b = b_img.load()
for y in range(ch):
    for x in range(cw):
        val = pixels_gray[x, y]
        if val > 240:
            alpha = 0
        elif val < 60:
            alpha = 255
        else:
            alpha = int((240 - val) / (240 - 60) * 255)
        pixels_b[x, y] = (0, 0, 0, alpha)

b_img.save(os.path.join(output_dir, "logo-dark.png"))
print("Saved logo-dark.png")

# Also create Variant 3: Default logo.png as white on transparent
w_img.save(os.path.join(output_dir, "logo.png"))
print("Saved logo.png")
