import os
from PIL import Image, ImageDraw

output_dir = r"C:\Users\e\.gemini\antigravity\scratch\portfolio"
logo_white = Image.open(os.path.join(output_dir, "logo-white.png")).convert("RGBA")

# 1. Generate favicon with gradient background and rounded corners
fav_size = 128
# Create gradient 135deg
grad = Image.new("RGBA", (fav_size, fav_size))
# Linear gradient from #6366f1 (99, 102, 241) to #a855f7 (168, 85, 247) to #ec4899 (236, 72, 153)
c1 = (99, 102, 241)
c2 = (168, 85, 247)
c3 = (236, 72, 153)

for y in range(fav_size):
    for x in range(fav_size):
        # diagonal factor 0..1
        t = (x + y) / (2.0 * fav_size)
        if t < 0.5:
            f = t * 2.0
            r = int(c1[0] + (c2[0] - c1[0]) * f)
            g = int(c1[1] + (c2[1] - c1[1]) * f)
            b = int(c1[2] + (c2[2] - c1[2]) * f)
        else:
            f = (t - 0.5) * 2.0
            r = int(c2[0] + (c3[0] - c2[0]) * f)
            g = int(c2[1] + (c3[1] - c2[1]) * f)
            b = int(c2[2] + (c3[2] - c2[2]) * f)
        grad.putpixel((x, y), (r, g, b, 255))

# Create rounded corner mask
mask = Image.new("L", (fav_size, fav_size), 0)
draw = ImageDraw.Draw(mask)
draw.rounded_rectangle([0, 0, fav_size - 1, fav_size - 1], radius=32, fill=255)

# Composite gradient with mask
bg_rounded = Image.new("RGBA", (fav_size, fav_size), (0, 0, 0, 0))
bg_rounded.paste(grad, (0, 0), mask=mask)

# Resize white logo to fit inside with padding
pad = 20
target_w = fav_size - 2 * pad
target_h = fav_size - 2 * pad
ratio = min(target_w / logo_white.width, target_h / logo_white.height)
new_w = int(logo_white.width * ratio)
new_h = int(logo_white.height * ratio)
resized_logo = logo_white.resize((new_w, new_h), Image.Resampling.LANCZOS)

# Paste centered
pos_x = (fav_size - new_w) // 2
pos_y = (fav_size - new_h) // 2
bg_rounded.paste(resized_logo, (pos_x, pos_y), mask=resized_logo)

# Save favicon.png
bg_rounded.save(os.path.join(output_dir, "favicon.png"))
print("Saved favicon.png")

# Also save an icon-badge version at 256x256 for high-res logo representation
badge_size = 256
grad256 = Image.new("RGBA", (badge_size, badge_size))
for y in range(badge_size):
    for x in range(badge_size):
        t = (x + y) / (2.0 * badge_size)
        if t < 0.5:
            f = t * 2.0
            r = int(c1[0] + (c2[0] - c1[0]) * f)
            g = int(c1[1] + (c2[1] - c1[1]) * f)
            b = int(c1[2] + (c2[2] - c1[2]) * f)
        else:
            f = (t - 0.5) * 2.0
            r = int(c2[0] + (c3[0] - c2[0]) * f)
            g = int(c2[1] + (c3[1] - c2[1]) * f)
            b = int(c2[2] + (c3[2] - c2[2]) * f)
        grad256.putpixel((x, y), (r, g, b, 255))

mask256 = Image.new("L", (badge_size, badge_size), 0)
draw256 = ImageDraw.Draw(mask256)
draw256.rounded_rectangle([0, 0, badge_size - 1, badge_size - 1], radius=64, fill=255)

badge = Image.new("RGBA", (badge_size, badge_size), (0, 0, 0, 0))
badge.paste(grad256, (0, 0), mask=mask256)

pad256 = 40
target_w = badge_size - 2 * pad256
target_h = badge_size - 2 * pad256
ratio = min(target_w / logo_white.width, target_h / logo_white.height)
new_w = int(logo_white.width * ratio)
new_h = int(logo_white.height * ratio)
resized_logo256 = logo_white.resize((new_w, new_h), Image.Resampling.LANCZOS)

pos_x = (badge_size - new_w) // 2
pos_y = (badge_size - new_h) // 2
badge.paste(resized_logo256, (pos_x, pos_y), mask=resized_logo256)

badge.save(os.path.join(output_dir, "logo-badge.png"))
# Also copy to artifact dir so we can view it
artifact_dir = r"C:\Users\e\.gemini\antigravity\brain\8108fd1a-8c35-4f08-a8af-de34d83ecdd3"
badge.save(os.path.join(artifact_dir, "logo_preview.png"))
print("Saved logo-badge.png and logo_preview.png")
