# گزارش به‌روزرسانی پورتفولیو — یکپارچه‌سازی دسته‌بندی‌ها و اختصاصی‌سازی نمونه‌کارها

دسته‌بندی‌های نمونه‌کارها بازآرایی شدند؛ پروژه‌های موشن‌گرافیک و ویدیو همگی تحت عنوان یکپارچه **«فیلم و موشن» (Film & Motion)** قرار گرفتند و تمام نمونه‌کارهای تستی/ماک‌آپی که قبلاً به عنوان جایگزین در قالب اولیه بودند حذف شدند. اکنون تنها ۹ پروژه واقعی ارسالی شما در سایت نمایش داده می‌شود.

---

## 🌐 آدرس وب‌سایت زنده (GitHub Pages):
👉 **[https://xashiap.github.io/portfolio/](https://xashiap.github.io/portfolio/)**

---

## 🗂 دسته‌بندی‌های فعال سایت:
1. **همه (`all`):** نمایش تمام ۹ نمونه‌کار اختصاصی شما.
2. **فیلم و موشن (`film`):** شامل هر ۸ ویدیوی تدوین و موشن‌گرافیک شما (`2.mp4` تا `9.mp4`).
3. **هوش مصنوعی (`ai`):** شامل ویدیوی بازآفرینی شاهکار شام آخر (`1.mp4`).

*(دسته‌بندی‌های متفرقه و خالی از نوار فیلتر حذف شدند تا ظاهر سایت کاملاً حرفه‌ای و متمرکز باشد).*

---

## 🎬 فهرست نهایی ۹ نمونه‌کار اختصاصی شما در سایت:

| ردیف | فایل ویدیو | دسته‌بندی | عنوان فارسی | عنوان انگلیسی | ابزارها |
| :---: | :---: | :---: | :--- | :--- | :---: |
| **۱** | `the_last_supper_528.mp4` | هوش مصنوعی (`ai`) | تبریک تولد با بازآفرینی شاهکارهای نقاشی (شام آخر) | The Last Supper Birthday — Classical Art AI Animation | `AI Video` • `AI Image Gen` • `After Effects` |
| **۲** | `project_2.mp4` | فیلم و موشن (`film`) | موشن‌استوری تبریک شب یلدا | Yalda Night Celebration — Motion Graphic Story | `After Effects` • `Illustrator` |
| **۳** | `project_3.mp4` | فیلم و موشن (`film`) | موشن‌استوری جذب نیرو و استخدام | Job Recruitment — Motion Graphic Story | `After Effects` • `Illustrator` |
| **۴** | `project_4.mp4` | فیلم و موشن (`film`) | موشن‌استوری دعوت به همکاری و استخدام | Job Hiring & Recruitment Motion Story | `After Effects` • `Illustrator` |
| **۵** | `project_5.mp4` | فیلم و موشن (`film`) | تیزر سه‌بعدی و جلوه‌های ویژه بیلبورد شهری (CGI / FOOH) | 3D VFX Urban Billboard Animation (FOOH / CGI) | `After Effects` • `3D Motion` • `Compositing` |
| **۶** | `project_6.mp4` | فیلم و موشن (`film`) | لوگو موشن اختصاصی و متحرک‌سازی نشان تجاری | Dynamic Brand Logo Animation & Identity Reveal | `After Effects` • `Illustrator` |
| **۷** | `project_7.mp4` | فیلم و موشن (`film`) | موشن‌استوری مناسبتی تبریک روز مهندس | Engineer's Day Celebration — Motion Graphic Story | `After Effects` • `3D Motion` • `Illustrator` |
| **۸** | `project_8.mp4` | فیلم و موشن (`film`) | موشن‌استوری مفهومی و انیمیشن شب یلدا | Conceptual Yalda Night Motion Story | `After Effects` • `Illustrator` |
| **۹** | `project_9.mp4` | فیلم و موشن (`film`) | موشن‌استوری کاراکتر انیمیشن و اطلاع‌رسانی | 2D Character Animation & Info Motion Story | `After Effects` • `Illustrator` • `Character Animation` |
