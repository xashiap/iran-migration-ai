Title: خشایار آذرپیرا | پورتفولیو تدوین، موشن گرافیک و گرافیک

Source: http://localhost:8080/index.html

---

[AZARPIRA.STUDIO](http://localhost:8080/index.html#home)
- [خانه](http://localhost:8080/index.html#home)
- [درباره من](http://localhost:8080/index.html#about)
- [مهارت‌ها](http://localhost:8080/index.html#skills)
- [نمونه‌کارها](http://localhost:8080/index.html#portfolio)
- [سوابق](http://localhost:8080/index.html#experience)
- [تماس](http://localhost:8080/index.html#contact)
[خانه](http://localhost:8080/index.html#home)
[درباره من](http://localhost:8080/index.html#about)
[مهارت‌ها](http://localhost:8080/index.html#skills)
[نمونه‌کارها](http://localhost:8080/index.html#portfolio)
[سوابق](http://localhost:8080/index.html#experience)
[تماس](http://localhost:8080/index.html#contact)

# سلام، من هنرمند دیجیتال تدوینگر ویدیو | طراح موشن گرافیک | طراح گرافیک
با تلفیق هنر، ریتم، رنگ و حرکت، ایده‌های شما را به ویدیوهای سینمایی و هویت‌های بصری خیره‌کننده تبدیل می‌کنم.
[مشاهده نمونه‌کارها](http://localhost:8080/index.html#portfolio)
[ارتباط با من](http://localhost:8080/index.html#contact)

##### Creative Post-Production
Crafting emotions frame by frame

## درباره من و دنیای تصویر
بیش از ۵ سال است که به عنوان تدوینگر، طراح موشن‌گرافیک و گرافیست، به برندها، یوتیوبرها و تیم‌های خلاق کمک می‌کنم تا پیام‌هایشان را با بالاترین کیفیت بصری منتقل کنند.
تخصص من از اصلاح رنگ سینمایی (Color Grading) و طراحی صدا (Sound Design) گرفته تا انیمیشن لوگو، تیزرهای تبلیغاتی و طراحی هویت بصری یکپارچه امتداد دارد. ریتم، جزئیات و انتقال حس در هر فریم، اولویت اصلی کار من است.

#### زمینه‌های تخصصی:

## نرم‌افزارها و مهارت‌های تخصصی
تسلط کامل بر استانداردترین ابزارهای صنعت تدوین و گرافیک برای خلق بالاترین استانداردهای بصری

### Adobe Premiere Pro
تدوین سینمایی، کات ریتمیک، سنک صدا و ترنزیشن

### Adobe After Effects
موشن گرافیک، تایتل، لوگو انیمیشن و جلوه‌های ویژه

### DaVinci Resolve
کالر گریدینگ حرفه‌ای، تنظیم نور، LUT و تطبیق رنگ

### Adobe Photoshop
طراحی پوستر، فتومونتاژ، روتوش عکس و کاور یوتیوب

### Adobe Illustrator
طراحی وکتور، آیکون، کاراکترهای موشن و لوگو

### Blender / Cinema 4D
مدل‌سازی سه بعدی، نورپردازی محصول و رندرهای تبلیغاتی

## نمونه‌کارهای برگزیده
مجموعه‌ای از پروژه‌های تیزر، موشن‌گرافیک، جلوه‌های ویژه و طراحی گرافیک

## سوابق کاری و تجربیات
سیر تکامل مهارت‌ها و پروژه‌های مهم در طول سال‌ها فعالیت

## بیایید با هم اثری شگفت‌انگیز خلق کنیم
ایده، تیزر، ویدیو یا پروژه‌ای در ذهن دارید؟ برای استعلام قیمت یا شروع همکاری پیام بفرستید.

### اطلاعات تماس مستقیم

###### ایمیل:
[contact@myportfolio.art](mailto:contact@myportfolio.art)

###### تلفن / واتساپ:
[+98 912 000 0000](tel:+989120000000)

###### تلگرام:
[@yourusername](https://t.me/yourusername)

###### موقعیت:
تهران، ایران (همکاری ریموت با سراسر دنیا)
© تمامی حقوق محفوظ است. | طراحی شده با عشق به هنر تصویر و حرکت

### Project Title
Project description and story...

