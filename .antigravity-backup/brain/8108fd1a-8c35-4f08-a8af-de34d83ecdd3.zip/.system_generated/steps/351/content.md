Title: Live Content

Description: Fetched live

Source: https://xashiap.github.io/portfolio/

---

<!DOCTYPE html>
<html lang="fa" dir="rtl" data-theme="dark">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>خشایار آذرپیرا | پورتفولیو تدوین، موشن گرافیک و گرافیک</title>
  <meta name="description" content="پورتفولیو و نمونه کارهای خشایار آذرپیرا در زمینه تدوین ویدیو، موشن گرافیک، اصلاح رنگ و طراحی گرافیک">
  <meta name="author" content="Khashayar Azarpira">
  
  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  
  <!-- Custom Stylesheet -->
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <!-- Ambient Glow Effects -->
  <div class="ambient-glow glow-1"></div>
  <div class="ambient-glow glow-2"></div>
  <div class="ambient-glow glow-3"></div>

  <!-- ==========================================================================
       NAVIGATION BAR
       ========================================================================== -->
  <nav class="navbar" id="navbar">
    <div class="container">
      <a href="#home" class="logo">
        <div class="logo-icon">
          <i class="fa-solid fa-film"></i>
        </div>
        <span class="logo-text"><span class="gradient-text">خشایار</span> آذرپیرا</span>
      </a>

      <ul class="nav-links" id="navLinks">
        <li><a href="#home" class="nav-link active" data-i18n="nav.home">خانه</a></li>
        <li><a href="#about" class="nav-link" data-i18n="nav.about">درباره من</a></li>
        <li><a href="#skills" class="nav-link" data-i18n="nav.skills">مهارت‌ها</a></li>
        <li><a href="#portfolio" class="nav-link" data-i18n="nav.portfolio">نمونه‌کارها</a></li>
        <li><a href="#experience" class="nav-link" data-i18n="nav.experience">سوابق</a></li>
        <li><a href="#contact" class="nav-link" data-i18n="nav.contact">تماس</a></li>
      </ul>

      <div class="nav-actions">
        <!-- Language Switcher Button -->
        <button class="icon-btn lang-btn" id="langToggle" title="تغییر زبان / Switch Language">
          <span id="langText">EN</span>
        </button>

        <!-- Dark/Light Theme Switcher Button -->
        <button class="icon-btn" id="themeToggle" title="تغییر تم / Toggle Theme">
          <i class="fa-solid fa-sun" id="themeIcon"></i>
        </button>

        <!-- Mobile Menu Hamburger -->
        <button class="icon-btn hamburger-btn" id="hamburgerBtn" aria-label="Menu">
          <i class="fa-solid fa-bars"></i>
        </button>
      </div>
    </div>
  </nav>

  <!-- ==========================================================================
       HERO SECTION
       ========================================================================== -->
  <section class="hero section" id="home">
    <div class="container">
      <div class="hero-grid">
        <div class="hero-content">
          <div class="badge-tag">
            <span class="pulse-dot"></span>
            <span data-i18n="hero.badge">آماده دریافت پروژه‌های جدید و همکاری ریموت</span>
          </div>

          <h1 class="hero-title">
            <span data-i18n="hero.greeting">سلام، من</span> <span class="gradient-text" data-i18n="hero.name">خشایار آذرپیرا</span> <br>
            <span style="font-size: 0.85em;" data-i18n="hero.role">تدوینگر ویدیو | طراح موشن گرافیک | طراح گرافیک</span>
          </h1>

          <p class="hero-description" data-i18n="hero.description">
            بیش از ۶ سال است که در زمینه تدوین تیزرهای تبلیغاتی، موشن‌گرافیک و طراحی گرافیک فعالیت می‌کنم و ایده‌ها را با ریتم و جلوه‌های بصری خیره‌کننده به تصویر می‌کشم.
          </p>

          <div class="hero-cta">
            <button class="btn btn-primary btn-glow" id="heroShowreelBtn">
              <i class="fa-solid fa-play"></i>
              <span data-i18n="hero.btnShowreel">تماشای شو ریل</span>
            </button>
            <a href="#portfolio" class="btn btn-secondary">
              <i class="fa-solid fa-layer-group"></i>
              <span data-i18n="hero.btnPortfolio">مشاهده نمونه‌کارها</span>
            </a>
            <a href="https://t.me/xashiap" target="_blank" class="btn btn-secondary">
              <i class="fa-brands fa-telegram"></i>
              <span data-i18n="hero.btnResume">پیام در تلگرام</span>
            </a>
            <a href="#contact" class="btn btn-secondary">
              <i class="fa-regular fa-paper-plane"></i>
              <span data-i18n="hero.btnContact">ارتباط با من</span>
            </a>
          </div>

          <div class="hero-socials">
            <a href="https://instagram.com/xashi_" target="_blank" class="social-link" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
            <a href="https://t.me/xashiap" target="_blank" class="social-link" title="Telegram"><i class="fa-brands fa-telegram"></i></a>
            <a href="https://wa.me/989351289395" target="_blank" class="social-link" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
            <a href="mailto:xashiwork@gmail.com" class="social-link" title="Email"><i class="fa-regular fa

