Title: Cached Content

Description: Fetched from cache

Source: https://recent.design/i/h98y98d-authkit

---

<!DOCTYPE html><html lang="en"><head><meta charSet="utf-8"/><meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover" name="viewport"/><script async="" data-token="8d7dbdd4-847f-445b-9249-4652b47c80ac" id="visitors-analytics" src="https://cdn.visitors.now/v.js"></script><title>Recent</title><meta content="The best of recent design found on the Internet updated daily." name="description"/><meta content="0453cb88-c99f-4d17-9d4a-4a88c5471bb8" name="impact-site-verification"/><meta content="The best of recent design found on the Internet updated daily." property="og:description"/><meta content="The best of recent design found on the Internet updated daily." name="twitter:description"/><meta name="twitter:title" content="Recent"/><meta name="twitter:creator" content="@recentdesign"/><meta name="twitter:site" content="@recentdesign"/><meta name="twitter:card" content="summary_large_image"/><meta name="twitter:image" content="https://recent.design/og.png"/><meta property="og:type" content="website"/><meta property="og:url" content="https://recent.design/i"/><meta property="og:title" content="Recent"/><meta property="og:image" content="https://recent.design/og.png"/><meta/><link rel="modulepreload" href="/assets/main-CPAWlKfq.js"/><link rel="modulepreload" href="/assets/route-DgtuAbta.js"/><link rel="modulepreload" href="/assets/auth-dialog-context-BL1_WzHD.js"/><link rel="modulepreload" href="/assets/presence-anchor-BqPpRJJ6.js"/><link rel="modulepreload" href="/assets/tokens.stylex-Dsf9ZjBz.js"/><link rel="modulepreload" href="/assets/index-Ct4xMYVA.js"/><link rel="modulepreload" href="/assets/sidebar-account-BtrtCcXG.js"/><link rel="modulepreload" href="/assets/item-url-D-ymxxp9.js"/><link rel="modulepreload" href="/assets/sidebar-navigation-X-ixTfxO.js"/><link rel="modulepreload" href="/assets/sidebar-sponsor-card-content-BqLHV1jy.js"/><link rel="modulepreload" href="/assets/use-sponsor-impression-BT0IEKRu.js"/><link rel="modulepreload" href="/assets/index-Bt_-u94J.js"/><link rel="modulepreload" href="/assets/use-scroll-fade-mask-Dndm590Y.js"/><link rel="modulepreload" href="/assets/auth-error-CKub95fb.js"/><link rel="modulepreload" href="/assets/use-login-CZjykHnC.js"/><link rel="modulepreload" href="/assets/index-BJ8R5l1D.js"/><link rel="modulepreload" href="/assets/auth-artwork-model-BDE-J_eE.js"/><link rel="modulepreload" href="/assets/media-url-DsDufp_x.js"/><link rel="modulepreload" href="/assets/loading-mask-BJPKUzGA.js"/><link rel="modulepreload" href="/assets/one-time-code-input-CL4c3fjk.js"/><link rel="modulepreload" href="/assets/dialog-C_EuXt3i.js"/><link rel="modulepreload" href="/assets/index-DVwGGVBF.js"/><link rel="modulepreload" href="/assets/useInteractions-C9TXWxfK.js"/><link rel="modulepreload" href="/assets/useOpenInteractionType-BQdJb34w.js"/><link rel="modulepreload" href="/assets/composite-C6yxMmzr.js"/><link rel="modulepreload" href="/assets/input-DY1TIylC.js"/><link rel="modulepreload" href="/assets/useMutation-DWzTyDFU.js"/><link rel="modulepreload" href="/assets/checkbox-Dr7v0bHC.js"/><link rel="modulepreload" href="/assets/index-D2LsIYUg.js"/><link rel="modulepreload" href="/assets/CompositeList-ZII1MXv1.js"/><link rel="modulepreload" href="/assets/index-De8ySGP6.js"/><link rel="modulepreload" href="/assets/useLabelableId-DcC8ZuEb.js"/><link rel="modulepreload" href="/assets/user-avatar-CRo9R41F.js"/><link rel="modulepreload" href="/assets/avatar-Ca5R2veF.js"/><link rel="modulepreload" href="/assets/radio-BRtHU8d2.js"/><link rel="modulepreload" href="/assets/CompositeItem-6HdqDF-t.js"/><link rel="modulepreload" href="/assets/media-dropzone-Ce6-6gw_.js"/><link rel="modulepreload" href="/assets/index-DZ0GUCYD.js"/><link rel="modulepreload" href="/assets/menu-DglmJ6dg.js"/><link rel="modulepreload" href="/assets/useListNavigation-Bo19Z04z.js"/><link rel="modulepreload" href="/assets/wrap-93fE8xgp.js"/><link rel="modulepreload" href="/assets/use-engagement-impression-DkEzQnCL.js"/><link rel="modulepreload" href="/assets/i._id-DiAYxScE.js"/><link rel="modulepreload" href="/assets/page-json-ld-BgiDRJ7c.js"/><link rel="modulepreload" href="/assets/use-body-scroll-lock-CthnVwF4.js"/><link rel="modulepreload" href="/assets/feed-media-slide-odxsR47A.js"/><link rel="modulepreload" href="/assets/save-button-lP1Ae7bP.js"/><link rel="modulepreload" href="/assets/index-C-EsiObI.js"/><link rel="modulepreload" href="/assets/item-metadata-labels-B6g6rlt3.js"/><link rel="modulepreload" href="/assets/use-relative-time-DjOhgXJa.js"/><link rel="modulepreload" href="/assets/index-CWJTmMWi.js"/><link href="/favicon.svg" rel="icon" type="image/svg+xml"/><link href="https://recent.design" rel="canonical"/><link rel="canonical" href="https://recent.design/i"/><link href="/assets/app-EI7oLUDT.css" rel="stylesheet"/></head><body><!--$--><div data-presence-anchor="shell" class="x78zum5 xdt5ytf x18fnhz4 xvueqy4 x185qao2 xg6iff7 xomhznc xh8yej3 x1tlwxzo xrxxuet x1a6j7ft"><aside data-presence-anchor="shell:sidebar" class="x7a106z xrvj5dj xqtt2cb x1o61qjw x16q0uzb x1cjqih5 x1cxnrsr xoihae8 x1h52sqi xc1n78f x1nocgrb x1mlnhw6 x1myq7io x18eaek x1eygso3 x2cmx5m"><div class="xjp7ctv x1cxnrsr x1vb3enb xoihae8 x1eloeus x1ogwb90"><div data-presence-scroll="y" data-scroll-lock-scroll="" class="xjp7ctv x1cjqih5 xzhf20h x1d9q8ru xv5yh4w x1eloeus x1m4w9oy xb8dal0 x144jk1y xbv1ute xhm9jum"><div class="xjp7ctv x1cxnrsr xoihae8 xc1n78f x1464ukb x1mgl66j"><div class="x6s0dn4 x78zum5 x1oibge4 x1ms6mhf x1qughib x17tnbgv xfk3qb9"><a aria-label="Recent" data-presence-anchor="shell:logo" href="/" class="x8v2xrv x1rg5ohu x86x1rc x7s97pk"><svg width="28" height="28" viewBox="0 0 32 32" fill="none" aria-hidden="true"><path d="M0 0.38C0 0.17 0.17 0 0.38 0H22c5.52 0 10 4.48 10 10s-4.48 10-10 10H0V0.38Z" fill="currentColor"></path><rect y="20" width="32" height="12" fill="currentColor"></rect></svg></a></div><nav aria-label="Primary navigation" data-presence-anchor="shell:navigation" class="x1cy8zhl xdt5ytf x1oay62h x1xdureb x1agbcgv x1s85apg x1cxnrsr"><section aria-labelledby="_R_qkqmlcq_" class="x1cy8zhl x78zum5 xdt5ytf x1oay62h xh8yej3"><div class="xh8yej3"><h2 id="_R_qkqmlcq_" class="xgjhfzy xloq5t5 xlb5dbd">Browse</h2></div><a data-presence-anchor="shell:nav:/" href="/" class="x1n2onr6 xdccri7 xt3l3uh x7gonq5 x1e8ascb x12w9bfk x6s0dn4 x78zum5 x1u5w1oc xjwf9q1 x1dtgwm3 x19tmk5i x1tz6pr4">Design</a><a data-presence-anchor="shell:nav:/websites" href="/websites" class="x1n2onr6 xdccri7 xt3l3uh x7gonq5 x1e8ascb x12w9bfk x6s0dn4 x78zum5 x1u5w1oc xjwf9q1 x1dtgwm3 x19tmk5i x1tz6pr4">Websites</a><a data-presence-anchor="shell:nav:/og-images" href="/og-images" class="x1n2onr6 xdccri7 xt3l3uh x7gonq5 x1e8ascb x12w9bfk x6s0dn4 x78zum5 x1u5w1oc xjwf9q1 x1dtgwm3 x19tmk5i x1tz6pr4">OG Images</a><a data-presence-anchor="shell:nav:/app-store-screenshots" href="/app-store-screenshots" class="x1n2onr6 xdccri7 xt3l3uh x7gonq5 x1e8ascb x12w9bfk x6s0dn4 x78zum5 x1u5w1oc xjwf9q1 x1dtgwm3 x19tmk5i x1tz6pr4">App Screenshots</a><a data-presence-anchor="shell:nav:/app-icons" href="/app-icons" class="x1n2onr6 xdccri7 xt3l3uh x7gonq5 x1e8ascb x12w9bfk x6s0dn4 x78zum5 x1u5w1oc xjwf9q1 x1dtgwm3 x19tmk5i x1tz6pr4">App Icons</a></section><section aria-labelledby="_R_1akqmlcq_" class="x1cy8zhl x78zum5 xdt5ytf x1oay62h xh8yej3 x1rz918b"><div class="xh8yej3"><h2 id="_R_1akqmlcq_" class="xgjhfzy xloq5t5 xlb5dbd">Resources</h2></div><a data-presence-anchor="shell:nav:/tools" href="/tools" class="x1n2onr6 xdccri7 xt3l3uh x7gonq5 x1e8ascb x12w9bfk x6s0dn4 x78zum5 x1u5w1oc xjwf9q1 x1dtgwm3 x19tmk5i x1tz6pr4">Tools</a><a data-presence-anchor="shell:nav:/skills" href="/skills" class="x1n2onr6 xdccri7 xt3l3uh x7gonq5 x1e8ascb x12w9bfk x6s0dn4 x78zum5 x1u5w1oc xjwf9q1 x1dtgwm3 x19tmk5i x1tz6pr4">Skills</a><a data-presence-anchor="shell:nav:/jobs" href="/jobs" class="x1n2onr6 xdccri7 xt3l3uh x7gonq5 x1e8ascb x12w9bfk x6s0dn4 x78zum5 x1u5w1oc xjwf9q1 x1dtgwm3 x19tmk5i x1tz6pr4">Jobs</a></section></nav><div class="x6s0dn4 x78zum5 xgfxd53 x1oibge4 x1ms6mhf x1qab1bc x1oob3yn"><button aria-label="Open Primary navigation" tabindex="0" data-base-ui-click-trigger="" id="_R_14qmlcq_" data-size="sm" data-slot="button" data-variant="ghost" class="x6s0dn4 xrwr6ys x9f619 xt0e3qv x3nfvp2 x2lah0s xlb5dbd x1r4xzce x1oay62h xn0d3qd xl56j7k xiq2fc0 x1n2onr6 x1hl2dhg x87ps6o xuxw1ft x10iet9p x1nwqle2 xgdra3a x1o7w7p3 x86x1rc x7s97pk xynox5x x1u2t6du xdccri7 x11vqxbs x7gonq5 x12w9bfk x1g0ag68 xkoi5ga xdpl792 x1y0btm7 xmkeg23 x12jquvc x1acvt2c xoj38cu x1plog1 xnjsko4 x78elm6 x8jbx7m xgj9iu6 xjbqb8w x146to3h" type="button"><span class="x6s0dn4 x3nfvp2 x14kbac9"><svg aria-hidden="true" class="xxk0z11 xvy4d1p" fill="none" height="24" viewBox="0 0 16 16" width="24" style="height:24px;width:24px"><path stroke="currentColor" stroke-linecap="round" stroke-width="1.25" vector-effect="non-scaling-stroke" d="M3 4L13 4M3 8L13 8"></path><path stroke="currentColor" stroke-linecap="round" stroke-width="1.25" vector-effect="non-scaling-stroke" d="M3 12L13 12"></path></svg></span></button></div><div class="x1s85apg x16q0uzb x1cxnrsr xoihae8 x1v1oca1 x1wdeaxd x1mgl66j"><footer data-slot="website-footer" class="x6s0dn4 x78zum5 xlb5dbd x1qughib xloq5t5 xh8yej3 xrobg6s"><span class="xgjhfzy">© 2026</span><nav aria-label="Company" class="x6s0dn4 x78zum5 xrobg6s"><a data-presence-anchor="shell:nav:/sponsor" href="/sponsor" class="x1tz6pr4 x1hl2dhg xdccri7 xt3l3uh x7gonq5 x1wcfchr x86x1rc x7s97pk x12w9bfk">Sponsor</a><a data-presence-anchor="shell:nav:/info" href="/info" class="x1tz6pr4 x1hl2dhg xdccri7 xt3l3uh x7gonq5 x1wcfchr x86x1rc x7s97pk x12w9bfk">Info</a></nav></footer></div></div></div></div></aside><div class="x78zum5 x98rzlu xdt5ytf xeuugli x1hy6njf"><div class="x98rzlu x1ov3xa9"></div></div><div class="x2lah0s x1oob3yn"><footer data-slot="website-footer" class="x6s0dn4 x78zum5 xlb5dbd x1qughib xloq5t5 xh8yej3 xrobg6s"><span class="xgjhfzy">© 2026</span><nav aria-label="Company" class="x6s0dn4 x78zum5 xrobg6s"><a data-presence-anchor="shell:nav:/sponsor" href="/sponsor" class="x1tz6pr4 x1hl2dhg xdccri7 xt3l3uh x7gonq5 x1wcfchr x86x1rc x7s97pk x12w9bfk">Sponsor</a><a data-presence-anchor="shell:nav:/info" href="/info" class="x1tz6pr4 x1hl2dhg xdccri7 xt3l3uh x7gonq5 x1wcfchr x86x1rc x7s97pk x12w9bfk">Info</a></nav></footer></div></div><script></script><script class="$tsr">(function restoreScroll({
  storageKey: storageKey2,
  key,
  behavior,
  shouldScrollRestoration,
  scrollToTopSelectors,
  location
}) {
  let byKey;
  try {
    byKey = JSON.parse(sessionStorage.getItem(storageKey2) || "{}");
  } catch (error2) {
    console.error(error2);
    return;
  }
  const resolvedKey = key || window.history.state?.__TSR_key;
  const elementEntries = byKey[resolvedKey];
  ignoreScroll = true;
  scroll: {
    if (shouldScrollRestoration && elementEntries && Object.keys(elementEntries).length > 0) {
      for (const elementSelector in elementEntries) {
        const entry = elementEntries[elementSelector];
        if (elementSelector === "window") {
          window.scrollTo({
            top: entry.scrollY,
            left: entry.scrollX,
            behavior
          });
        } else if (elementSelector) {
          const element = document.querySelector(elementSelector);
          if (element) {
            element.scrollLeft = entry.scrollX;
            element.scrollTop = entry.scrollY;
          }
        }
      }
      break scroll;
    }
    const hash = (location ?? window.location).hash.split("#", 2)[1];
    if (hash) {
      const hashScrollIntoViewOptions = window.history.state?.__hashScrollIntoViewOptions ?? true;
      if (hashScrollIntoViewOptions) {
        const el = document.getElementById(hash);
        if (el) {
          el.scrollIntoView(hashScrollIntoViewOptions);
        }
      }
      break scroll;
    }
    const scrollOptions = { top: 0, left: 0, behavior };
    window.scrollTo(scrollOptions);
    if (scrollToTopSelectors) {
      for (const selector of scrollToTopSelectors) {
        if (selector === "window") continue;
        const element = typeof selector === "function" ? selector() : document.querySelector(selector);
        if (element) element.scrollTo(scrollOptions);
      }
    }
  }
  ignoreScroll = false;
})({"storageKey":"tsr-scroll-restoration-v1_3","shouldScrollRestoration":true});typeof $_TSR !== "undefined" && $_TSR.c()</script><!--/$--><script class="$tsr" id="$tsr-stream-barrier">(self.$R=self.$R||{})["tsr"]=[];self.$_TSR={c(){self.$_TSR_DEFER||(document.querySelectorAll(".\\$tsr").forEach(e=>{e.remove()}),this.hydrated&&this.streamEnd&&(delete self.$_TSR,delete self.$R.tsr))},cleanup(){document.querySelectorAll(".\\$tsr").forEach(e=>{e.remove()}),this.hydrated&&this.streamEnd&&(delete self.$_TSR,delete self.$_TSR_DEFER,delete self.$R.tsr)},p(e){this.initialized?e():this.buffer.push(e)},buffer:[]};
;$_TSR.router=($R=>$R[0]={manifest:$R[1]={routes:$R[2]={__root__:$R[3]={preloads:$R[4]=["/assets/main-CPAWlKfq.js"],assets:$R[5]=[$R[6]={tag:"script",attrs:$R[7]={type:"module",async:!0},children:"import('/assets/main-CPAWlKfq.js')"}]},"/(site)":$R[8]={preloads:$R[9]=["/assets/route-DgtuAbta.js","/assets/auth-dialog-context-BL1_WzHD.js","/assets/presence-anchor-BqPpRJJ6.js","/assets/tokens.stylex-Dsf9ZjBz.js","/assets/index-Ct4xMYVA.js","/assets/sidebar-account-BtrtCcXG.js","/assets/item-url-D-ymxxp9.js","/assets/sidebar-navigation-X-ixTfxO.js","/assets/sidebar-sponsor-card-content-BqLHV1jy.js","/assets/use-sponsor-impression-BT0IEKRu.js","/assets/index-Bt_-u94J.js","/assets/use-scroll-fade-mask-Dndm590Y.js","/assets/auth-error-CKub95fb.js","/assets/use-login-CZjykHnC.js","/assets/index-BJ8R5l1D.js","/assets/auth-artwork-model-BDE-J_eE.js","/assets/media-url-DsDufp_x.js","/assets/loading-mask-BJPKUzGA.js","/assets/one-time-code-input-CL4c3fjk.js","/assets/dialog-C_EuXt3i.js","/assets/index-DVwGGVBF.js","/assets/useInteractions-C9TXWxfK.js","/assets/useOpenInteractionType-BQdJb34w.js","/assets/composite-C6yxMmzr.js","/assets/input-DY1TIylC.js","/assets/useMutation-DWzTyDFU.js","/assets/checkbox-Dr7v0bHC.js","/assets/index-D2LsIYUg.js","/assets/CompositeList-ZII1MXv1.js","/assets/index-De8ySGP6.js","/assets/useLabelableId-DcC8ZuEb.js","/assets/user-avatar-CRo9R41F.js","/assets/avatar-Ca5R2veF.js","/assets/radio-BRtHU8d2.js","/assets/CompositeItem-6HdqDF-t.js","/assets/media-dropzone-Ce6-6gw_.js","/assets/index-DZ0GUCYD.js","/assets/menu-DglmJ6dg.js","/assets/useListNavigation-Bo19Z04z.js","/assets/wrap-93fE8xgp.js","/assets/use-engagement-impression-DkEzQnCL.js"]},"/(site)/i/$id":$R[10]={preloads:$R[11]=["/assets/i._id-DiAYxScE.js","/assets/page-json-ld-BgiDRJ7c.js","/assets/use-body-scroll-lock-CthnVwF4.js","/assets/feed-media-slide-odxsR47A.js","/assets/save-button-lP1Ae7bP.js","/assets/index-C-EsiObI.js","/assets/item-metadata-labels-B6g6rlt3.js","/assets/use-relative-time-DjOhgXJa.js","/assets/index-CWJTmMWi.js"]}}},matches:$R[12]=[$R[13]={i:"__root__/",u:1790424052987,s:"success",ssr:!0},$R[14]={i:"/(site)/",u:1790424052987,s:"success",ssr:!0},$R[15]={i:"/(site)/i/$id/i/h98y98d-authkit",u:1790424052987,s:"success",ssr:!0}],lastMatchId:"/(site)/i/$id/i/h98y98d-authkit",dehydratedData:$R[16]={queryStream:$R[17]=($R[18]=(stream) => new ReadableStream({ start(controller) {
  stream.on({
    next(value) {
      try {
        controller.enqueue(value);
      } catch (_error) {
      }
    },
    throw(value) {
      controller.error(value);
    },
    return() {
      try {
        controller.close();
      } catch (_error) {
      }
    }
  });
} }))($R[19]=($R[20]=() => {
  const buffer = [];
  const listeners = [];
  let alive = true;
  let success2 = false;
  let count = 0;
  const internal = {
    flush(value, mode, x) {
      for (x = 0; x < count; x++) if (listeners[x]) listeners[x][mode](value);
    },
    up(listener, x, z, current) {
      for (x = 0, z = buffer.length; x < z; x++) {
        current = buffer[x];
        if (!alive && x === z - 1) listener[success2 ? "return" : "throw"](current);
        else listener.next(current);
      }
    },
    on(listener, temp) {
      if (alive) {
        temp = count++;
        listeners[temp] = listener;
      }
      internal.up(listener);
      return () => {
        if (alive) {
          listeners[temp] = listeners[count];
          listeners[count--] = void 0;
        }
      };
    }
  };
  return {
    __SEROVAL_STREAM__: true,
    on(listener) {
      return internal.on(listener);
    },
    next(value) {
      if (alive) {
        buffer.push(value);
        internal.flush(value, "next");
      }
    },
    throw(value) {
      if (alive) {
        buffer.push(value);
        internal.flush(value, "throw");
        alive = false;
        success2 = false;
        listeners.length = 0;
      }
    },
    return(value) {
      if (alive) {
        buffer.push(value);
        internal.flush(value, "return");
        alive = false;
        success2 = true;
        listeners.length = 0;
      }
    }
  };
})())}})($R["tsr"]);$_TSR.c()</script><script type="module" async="">import('/assets/main-CPAWlKfq.js')</script><script class='$tsr'>($R=>$R[19].return(void 0))($R["tsr"]);$_TSR.streamEnd=true;$_TSR.c()</script><script type="module" src="https://static.cloudflareinsights.com/beacon.min.js/v31edd6df95cf4e85bb4c19e7a9bdbcba1788362987495" integrity="sha512-iIg7k2xntmwu6/uSb5tpc/hySgZc4eoL31yB29W6tJFo2akwjPWcEqnCEdJvGexCL0KEQwVYv5BlowfhVz26hg==" data-cf-beacon='{"version":"2024.11.0","token":"39f548f4210442fab78e878bcd2ba567","r":1,"spa":2}' crossorigin="anonymous"></script>
</body></html>

