# طرح پیاده‌سازی: سیستم به‌روزرسانی خودکار و هوشمند رادار فرصت‌ها (Auto-Updating Radar)

## شرح هدف و قابلیت جدید
تبدیل بخش «رادار روزانه فرصت‌های مهاجرتی» از یک دیتابیس ثابت کدی به یک **سیستم زنده، هوشمند و خودکار (Live Auto-Updating Engine)** که به صورت دوره‌ای و خودکار، بدون نیاز به دخالت دست، جدیدترین فرصت‌های شغلی اسپانسر‌دار و بورسیه‌های تحصیلی را با تاریخ‌های جدید تولید و ذخیره کرده و به کاربران نمایش می‌دهد. همچنین امکان مدیریت کامل (افزودن، ویرایش، حذف و آپدیت دستی) از پنل ادمین را فراهم می‌سازد.

---

## بررسی و تایید کاربر (User Review Required)

> [!IMPORTANT]
> **نحوه عملکرد اتوماسیون بدون هزینه:**
> ۱. **کران جاب خودکار (Vercel Cron):** هر روز صبح به وقت تهران به صورت خودکار اندپوینت `/api/cron/radar-refresh` را صدا می‌زند تا فرصت‌های تاریخ‌گذشته بایگانی شده و فرصت‌های جدید با هوش مصنوعی اضافه شوند.
> ۲. **پایداری ابری رایگان (Cloud Sync Persistence):** با همان معماری هوشمند `db.ts` (اتصال به سرورلس و گیت‌هاب)، فرصت‌های جدید در فضای ابری ذخیره شده و با ریست شدن سرورلس پاک نمی‌شوند.
> ۳. **مدیریت از پنل ادمین (`/admin`):** تب جدیدی به پنل ادمین شما اضافه می‌شود تا بتوانید با یک کلیک دکمه «تولید هوشمند» را بزنید یا هر فرصتی که مایل بودید را خودتان دستی ثبت کنید.
> ۴. **لود فوری در فرانت‌اند:** کامپوننت رادار با اتصال به API آخرین اطلاعات را دریافت می‌کند و اگر اینترنت قطع باشد، به دیتابیس درونی رجوع می‌کند تا رادار همیشه بالا بماند.

---

## تغییرات پیشنهادی در فایل‌ها

### ۱. لایه پایداری و ذخیره‌سازی داده (`Store & Persistence Layer`)

#### [NEW] [opportunitiesStore.ts](file:///C:/Users/e/.gemini/antigravity/scratch/iran-migration-ai/src/lib/opportunitiesStore.ts)
- نگهداری حافظه کَش (In-Memory Cache) + دیسک موقت `/tmp` + اتصال به فضای ابری گیت‌هاب برای ماندگاری دائم.
- ترکیب ۲۷ فرصت پایه با فرصت‌های داینامیک جدید.
- توابع: `getAllOpportunities()`, `addOpportunity()`, `deleteOpportunity()`, `refreshOpportunitiesWithAI()`.

---

### ۲. اندپوینت‌های سرور (`Backend API Routes`)

#### [MODIFY] [route.ts (api/opportunities)](file:///C:/Users/e/.gemini/antigravity/scratch/iran-migration-ai/src/app/api/opportunities/route.ts)
- اتصال به `opportunitiesStore.getAllOpportunities()` برای تحویل زنده تمام فرصت‌ها (پایه + داینامیک).

#### [NEW] [route.ts (api/cron/radar-refresh)](file:///C:/Users/e/.gemini/antigravity/scratch/iran-migration-ai/src/app/api/cron/radar-refresh/route.ts)
- اندپوینت دریافت درخواست خودکار Vercel Cron.
- تولید پوزیشن‌های جدید با معیارهای واقعی (حقوق‌های ۲۰۲۶، بورسیه‌های معتبر، ددلاین‌های روز) با استفاده از جمینای یا الگوریتم هوشمند جایگزین در صورت آفلاین بودن کلید.

#### [NEW] [route.ts (api/admin/opportunities)](file:///C:/Users/e/.gemini/antigravity/scratch/iran-migration-ai/src/app/api/admin/opportunities/route.ts)
- مدیریت امن ادمین با پسورد `Ko9351289395@` برای افزودن، حذف و تریگر کردن آپدیت دستی رادار.

---

### ۳. تنظیمات دیپلوی سرور Vercel

#### [NEW] [vercel.json](file:///C:/Users/e/.gemini/antigravity/scratch/iran-migration-ai/vercel.json)
- تعریف تسک زمان‌بندی‌شده Cron روزانه:
  ```json
  {
    "crons": [
      {
        "path": "/api/cron/radar-refresh",
        "schedule": "0 6 * * *"
      }
    ]
  }
  ```

---

### ۴. رابط کاربری (`Frontend UI`)

#### [MODIFY] [ImmigrationRadar.tsx](file:///C:/Users/e/.gemini/antigravity/scratch/iran-migration-ai/src/components/Radar/ImmigrationRadar.tsx)
- دریافت داده‌های رادار به صورت زنده از `/api/opportunities` به جای ایمپورت استاتیک.
- نمایش نشانگر وضعیت ارتباط ابری رادار (پالس سبز "رادار فعال و متصل به سرور").
- دکمه رفرش زنده برای دریافت جدیدترین موقعیت‌ها بدون نیاز به رفرش کل صفحه.

#### [MODIFY] [page.tsx (admin)](file:///C:/Users/e/.gemini/antigravity/scratch/iran-migration-ai/src/app/admin/page.tsx)
- افزودن تب «مدیریت رادار فرصت‌ها» در پنل مدیریت.
- دکمه تریگر فوری «آپدیت هوشمند رادار با هوش مصنوعی».
- جدول نمایش فرصت‌ها همراه با امکان حذف و دکمه افزودن فرصت جدید.

---

## برنامه راستی‌آزمایی و تست (Verification Plan)

### تست‌های خودکار و کامپایل:
- اجرای `npm run build` جهت اطمینان از صحت تمامی تایپ‌های TypeScript و روت‌های جدید.
- تست تریگر کردن اندپوینت `/api/cron/radar-refresh` و بررسی اضافه شدن آیتم جدید به لیست.
- تست فراخوانی `/api/opportunities` و تایید دریافت فرصت‌های داینامیک.

### استقرار و تست آنلاین:
- ارسال کدها به گیت‌هاب و انتشار روی Vercel.
- تست افزودن یا رفرش فرصت‌ها در پنل ادمین و مشاهده نمایش آن در صفحه اصلی رادار.
