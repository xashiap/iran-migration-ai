# ScenarioAI - پلتفرم سناریونویس هوشمند

## معماری کلی

### Stack
- **Frontend**: Next.js 14 (App Router) + TypeScript + Tailwind CSS
- **AI**: Google Gemini API (gemini-1.5-pro)
- **UI Components**: shadcn/ui
- **State**: Zustand
- **Export**: jsPDF for PDF export

### صفحات اصلی

1. **`/`** - صفحه اصلی / ورود اطلاعات کسب‌وکار
   - فرم ورود نوع کسب‌وکار
   - انتخاب پلتفرم هدف (اینستاگرام/ریلز، تلویزیون)
   - دکمه "جستجوی ترندها و تولید سناریو"

2. **`/scenarios`** - نمایش سناریوهای پیشنهادی
   - لیست 3-5 سناریو تولیدشده
   - هر سناریو: عنوان، خلاصه، قالب، مدت زمان، ایده اصلی
   - دکمه تایید / رد هر سناریو
   - دکمه "ادامه با سناریوی انتخابی"

3. **`/storyboard/:id`** - استوری‌برد تعاملی
   - نمایش صحنه‌به‌صحنه
   - توضیح دوربین، نور، دیالوگ، جلوه‌های بصری
   - قابلیت ویرایش هر صحنه
   - خروجی PDF

### جریان کار
```
کاربر اطلاعات کسب‌وکار وارد می‌کند
    ↓
Gemini API ترندها را جستجو می‌کند
    ↓
3-5 سناریوی خلاقانه تولید می‌شود
    ↓
کاربر سناریوی مورد نظر را تایید می‌کند
    ↓
استوری‌برد کامل تولید می‌شود
    ↓
خروجی PDF / مدیریت پروژه
```

### API Routes
- `POST /api/generate-scenarios` - تولید سناریو با Gemini
- `POST /api/generate-storyboard` - تولید استوری‌برد
- `GET /api/trends` - جستجوی ترندها

### فولدر استراکچر
```
scenarioai/
├── app/
│   ├── page.tsx                    (صفحه اصلی)
│   ├── scenarios/page.tsx          (لیست سناریوها)
│   ├── storyboard/[id]/page.tsx    (استوری‌برد)
│   ├── api/
│   │   ├── generate-scenarios/route.ts
│   │   ├── generate-storyboard/route.ts
│   │   └── trends/route.ts
│   └── layout.tsx
├── components/
│   ├── ScenarioCard.tsx
│   ├── StoryboardPanel.tsx
│   ├── BusinessForm.tsx
│   └── ui/ (shadcn)
├── lib/
│   ├── gemini.ts
│   └── store.ts (Zustand)
└── ...
```
