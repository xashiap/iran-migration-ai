const https = require('https');
const models = ['gemini-3.8-flash','gemini-3.5-flash','gemini-3.1-flash-lite','gemini-2.5-flash-lite','gemini-flash-latest'];
const key = 'AQ.Ab8RN6KmRGr-_r5m76A86SR68aqvtEcUR8fhIGrK-g7doi_w2A';

function test(model) {
  return new Promise((resolve) => {
    const body = JSON.stringify({contents:[{parts:[{text:'say hi'}]}]});
    const start = Date.now();
    const options = {
      hostname: 'generativelanguage.googleapis.com',
      path: '/v1beta/models/' + model + ':generateContent?key=' + key,
      method: 'POST',
      headers: {'Content-Type':'application/json','Content-Length':Buffer.byteLength(body)}
    };
    const req = https.request(options, function(res) {
      let d = '';
      res.on('data', function(c){ d += c; });
      res.on('end', function(){ resolve({model: model, status: res.statusCode, ms: Date.now()-start}); });
    });
    req.on('error', function(){ resolve({model: model, status: 'ERR', ms: Date.now()-start}); });
    req.write(body);
    req.end();
  });
}

async function main() {
  for (var i = 0; i < models.length; i++) {
    var r = await test(models[i]);
    console.log((r.status === 200 ? 'OK  ' : 'FAIL'), r.ms + 'ms', r.model);
  }
}

main();
